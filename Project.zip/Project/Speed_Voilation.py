""" To find the regions where the speed limit is exceeded """

def speed_violation(speed,GpsTime, df):
    SPEED_VIOLATION = []
    GPS_TIME = []
    LONGITUDE_DATA = [] 
    LATITUDE_DATA = []
    SPEED = []

    for i in df.index:
	  if speed[i]== '-' :
         speed[i]= '0';
      if (float(speed[i])>20):
        SPEED_VIOLATION.append([df[' Latitude'][i],df[' Longitude'][i]])
        GPS_TIME.append(GpsTime[i])
        LONGITUDE_DATA.append(Longitude[i])
        LATITUDE_DATA.append(Latitude[i])
    VIOLATION = pd.DataFrame(data=SPEED_VIOLATION, columns=['Latitude', 'Longitude'])
    return VIOLATION

