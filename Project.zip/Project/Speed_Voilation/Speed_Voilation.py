import pandas as pd
import os
import matplotlib.pyplot as plt


def speed_violation(speed,GpsTime, Latitude,Longitude,Threshold_Speed):
	SPEED_VIOLATION = []
	GPS_TIME = []
	for i in df.index:
		if speed[i]== '-' :
			speed[i]= '0';
		if (float(speed[i])>Threshold_Speed):
			SPEED_VIOLATION.append([Latitude[i],Longitude[i],GpsTime[i],speed[i],i])
	VIOLATION = pd.DataFrame(data=SPEED_VIOLATION, columns=['Latitude', 'Longitude','GPS_Time','Speed','Index'])
	return VIOLATION

  """plt.plot(trip_time, coolant_temperature_Faranheit, "r")
  plt.xlabel("Trip Time")
  plt.ylabel("Coolant Temperature")
  plt.title("Engine Coolant Temperature Management")
  plt.show()

df = pd.read_excel("Project/trackLog-2020-Jan-02_16-22-5858.xlsx")
"""



