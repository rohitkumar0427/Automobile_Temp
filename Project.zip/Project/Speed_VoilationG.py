import pandas as pd
import os
import matplotlib.pyplot as plt


def speed_violation(speed,GpsTime, Latitude,Longitude,Threshold_Speed):
	SPEED_VIOLATION = []
	GPS_TIME = []
	for i in df.index:
		if speed[i]== '-' :
			speed[i]= '0';
		if (float(speed[i])>Threshold_Speed):
			SPEED_VIOLATION.append([Latitude[i],Longitude[i],GpsTime[i],speed[i],i])
	VIOLATION = pd.DataFrame(data=SPEED_VIOLATION, columns=['Latitude', 'Longitude','GPS_Time','Speed','Index'])
	return VIOLATION

df = pd.read_excel("trackLog-2020-Jan-02_16-22-5858.xlsx")
Speed_violate=speed_violation(df["Speed (GPS)(km/h)"],df["GPS Time"],df[' Latitude'],df[' Longitude'],20)
t=df["Speed (GPS)(km/h)"]
plt.plot(t,marker='o')
plt.plot(Speed_violate['Index'],Speed_violate['Speed'], 'ro')
plt.show()
