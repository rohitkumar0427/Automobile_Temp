import unittest
import Coolant_Temperature
import pandas as pd
import matplotlib.pyplot as plt
import os

class TestCoolant_Temperature(unittest.TestCase):
	def testCoolantTemperature(self):
		try:
			df_File = pd.read_excel("List_of_Data_Set.xlsx")
			os.system('mkdir Result')
			for i in df_File.index:
				df = pd.read_excel(str(df_File["Input_File_Name"][i]))
				Coolant_temperature=Coolant_Temperature.coolant(df['Engine Coolant Temperature(Â°C)'].replace(to_replace="-", value="0"),df['Engine Load(%)'].replace(to_replace="-", value="0"),df['Trip Time(Since journey start)(s)'].replace(to_replace="-", value="0"))
				t=df["Engine Coolant Temperature(Â°C)"]
				t2=t.replace(to_replace='-',value=0)
				plt.figure(1)
				plt.plot(t2,marker='o')
				plt.plot(Coolant_temperature['Index'],Coolant_temperature['Coolant_Temperature'], 'ro')
				t1=df_File["Input_File_Name"][i].split('/')
				t3=t1[-1].split('.')
				plt.savefig('Result/'+str(t3[0])+'.png')
				
				t=df["Engine Load(%)"]
				t2=t.replace(to_replace='-',value=0)
				plt.figure(1)
				plt.plot(t2,marker='o')
				plt.plot(Coolant_temperature['Index'],Coolant_temperature['Engine Load(%)'], 'ro')
				t1=df_File["Input_File_Name"][i].split('/')
				t3=t1[-1].split('.')
				plt.savefig('Result/'+str(t3[0])+'.png')
				
				t=df["Trip Time(Since journey start)(s)"]
				t2=t.replace(to_replace='-',value=0)
				plt.figure(1)
				plt.plot(t2,marker='o')
				plt.plot(Coolant_temperature['Index'],Coolant_temperature['Trip Time(Since journey start)(s)'], 'ro')
				t1=df_File["Input_File_Name"][i].split('/')
				t3=t1[-1].split('.')
				plt.savefig('Result/'+str(t3[0])+'.png')


			
		except AssertionError as e:
			f = open("Difference_Report_Speed_Voilation", "a")
			f.write("TestCase_no_0:\n\t"+str(e)+" \n")

if __name__ == '__main__':
	unittest.main()

