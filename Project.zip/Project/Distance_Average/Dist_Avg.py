!pip install shapely
!pip install geopandas
!pip install osmapi

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from shapely.geometry import Point
import geopandas as gpd
import plotly.graph_objects as go
import plotly.express as px

def distavg(dist,fuel,kmpl):
    final = dist.iloc[-1]
    final = float(final)
    print("The total distance covered:", final)
    rem_fuel = fuel.iloc[-1]
    rem_fuel = float(rem_fuel)
    used = 100 - rem_fuel
    used = used/100
    print("fuel used:", used)
    for i in range(len(kmpl)):
        kmpl[i] = float(kmpl[i])
    x = kmpl.mean()
    print("kpl avg:", x)
    x = x*used
    print("exp distance", x)
    diff = x-final
    print(diff)